var input = document.querySelectorAll('.required');
var span = document.querySelectorAll('.span-alert');
const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const senhaRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#+-])[A-Za-z\d@$!%*?&#+-]{8,}$/;
const cpfRegex = /^[\d.-]{14,}$/;
const telRegex = /^(?=.*[(])(?=.*[\d])(?=.*[)])(?=.*[\d])(?=.*[-])(?=.*[\d])[()\d-]{14,}$/;

function setError(index){
    input[index].style.border = '2px solid red';
    span[index].style.display = 'block';
    input[index].style.outline = "0";
}

function removeError(index){
    input[index].style.border = '';
    span[index].style.display = 'none';
    input[index].style.outline = "1";
}

function NameValidate(){
    if(input[0].value.length < 2){
        setError(0);
    }
    else{
        removeError(0);
    }
}

function LastNameValidate(){
    if(input[1].value.length < 2){
        setError(1);
    }
    else{
        removeError(1);
    }
}

function EmailValidate(){
    if(input[2].value.match(emailRegex)){
        removeError(2);
    }
    else{
        setError(2);
    }
}

function PasswordValidate(){
    if(input[3].value.match(senhaRegex)){
        removeError(3);
    }
    else
    {
        setError(3);
    }
    if(input[4].value.match(input[3].value)){
        removeError(4);
    }
    else{
        setError(4);
    }
}

function CpfValidate(){
    if(input[6].value.length == 3){
        input[6].value += "."
    }
    else if(input[6].value.length == 7){
        input[6].value += "."
    }
    else if(input[6].value.length == 11){
        input[6].value += "-"
    }
    if(input[6].value.match(cpfRegex)){
        removeError(6);
    }
    else{
        setError(6);
    }
}

function PhoneValidate()
        {
           //limitador
         var tel = document.getElementById("telefone").value
            console.log(tel)
          tel=tel.slice(0,14) //(pode limitar a quantidade de char na entrada pelo java script)
            console.log(tel)
          document.getElementById("telefone").value=tel
     tel=document.getElementById("telefone").value.slice(0,10)
            console.log(tel)
           
            //máscara
            var tel_formatado = document.getElementById("telefone").value
            if (tel_formatado[0]!="(")
            {
                if(tel_formatado[0]!=undefined)
                {
                    document.getElementById("telefone").value="("+tel_formatado[0];
                }
            }

            if (tel_formatado[3]!=")")
            {
                if(tel_formatado[3]!=undefined)
                {
                    document.getElementById("telefone").value=tel_formatado.slice(0,3)+")"+tel_formatado[3]
                }
            }

            if (tel_formatado[9]!="-")
            {
                if(tel_formatado[9]!=undefined)
                {
                    document.getElementById("telefone").value=tel_formatado.slice(0,9)+"-"+tel_formatado[9]
                }
            }
        }

/*TESTE2
const form = document.getElementById('form-section');
const spans = document.querySelectorAll('.span-alert');

const campos = document.querySelectorAll('.required')

function setError(index){
    campos[index].style.border = '2px solid red';
    spans[index].style.display = 'block';
}

function removeError(index){
    campos[index].style.border = '';
    spans[index].style.display = 'none';
}

function validarnome(){
    if(campos[0].value.length < 2)
    {
        setError(0);
        console.log('teste');
    }
    else
    {
        removeError(0);
    }
}

function validarEmail(){
    if(!emailRegex.test(campos[1].value))
    {
        console.log('teste');
    }
    else
    {
        console.log('teste');
    }
}
*/

/*TESTE MEU
function mascaraCPF(){
    var cpf = document.getElementById('CPF')
    if(cpf.value.length == 3 || cpf.value.length == 7){
        cpf.value+="."
    }
    else if(cpf.value.length == 11){
        cpf.value+="-"
    }
}

function mascaraTel(){
    const input = document.getElementById("telefone");

    input.addEventListener("keyup", formatarTelefone);

    function formatarTelefone(e){
        var v=e.target.value.replace(/\D/g,"");
        v=v.replace(/^(\d\d)(\d)/g,"($1)$2"); 
        v=v.replace(/(\d{5})(\d)/,"$1-$2");    
        e.target.value = v;
    }
}

function mascaraCep(){
    var cep = document.getElementById('CEP')
    if(cep.value.length == 5){
        cep.value+="-"
    }
}
*/
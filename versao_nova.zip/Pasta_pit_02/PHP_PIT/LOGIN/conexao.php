<?php
//Dados do banco de dados
define('HOST', '127.0.0.1');
define('USUARIO', 'root');
define('SENHA', '');
define('DB','bancodedados_petch1');

//Conexão com o banco, função "or die" caso na conecte
$conexao = mysqli_connect(HOST,USUARIO,SENHA,DB) or die ("Não conectou");
?>
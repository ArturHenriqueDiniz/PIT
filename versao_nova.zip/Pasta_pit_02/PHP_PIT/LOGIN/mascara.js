var input = document.querySelectorAll('.required');
var span = document.querySelectorAll('.span-alert');
const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const senhaRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#+-])[A-Za-z\d@$!%*?&#+-]{8,}$/;

function setError(index){
    input[index].style.border = '2px solid red';
    span[index].style.display = 'block';
    input[index].style.outline = "0";
}

function removeError(index){
    input[index].style.border = '';
    span[index].style.display = 'none';
    input[index].style.outline = "1";
}

function EmailValidate(){
    if(input[0].value.match(emailRegex)){
        removeError(0);
    }
    else{
        setError(0);
    }
}

function PasswordValidate(){
    if(input[1].value.match(senhaRegex)){
        removeError(1);
    }
    else
    {
        setError(1);
    }
}


/*TESTE2
const form = document.getElementById('form-section');
const spans = document.querySelectorAll('.span-alert');

const campos = document.querySelectorAll('.required')

function setError(index){
    campos[index].style.border = '2px solid red';
    spans[index].style.display = 'block';
}

function removeError(index){
    campos[index].style.border = '';
    spans[index].style.display = 'none';
}

function validarnome(){
    if(campos[0].value.length < 2)
    {
        setError(0);
        console.log('teste');
    }
    else
    {
        removeError(0);
    }
}

function validarEmail(){
    if(!emailRegex.test(campos[1].value))
    {
        console.log('teste');
    }
    else
    {
        console.log('teste');
    }
}
*/

/*TESTE MEU
function mascaraCPF(){
    var cpf = document.getElementById('CPF')
    if(cpf.value.length == 3 || cpf.value.length == 7){
        cpf.value+="."
    }
    else if(cpf.value.length == 11){
        cpf.value+="-"
    }
}

function mascaraTel(){
    const input = document.getElementById("telefone");

    input.addEventListener("keyup", formatarTelefone);

    function formatarTelefone(e){
        var v=e.target.value.replace(/\D/g,"");
        v=v.replace(/^(\d\d)(\d)/g,"($1)$2"); 
        v=v.replace(/(\d{5})(\d)/,"$1-$2");    
        e.target.value = v;
    }
}

function mascaraCep(){
    var cep = document.getElementById('CEP')
    if(cep.value.length == 5){
        cep.value+="-"
    }
}
*/
<!DOCTYPE html>
<html lang="en">

<?php
        header('Content-type: text/html; charset=utf-8');
    ?>

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cadastro</title>
  <link rel="stylesheet" href="styles.css" />
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous" />
  <!-- Bootstrap icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css" />
</head>

<body id="checkout-page">
<header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LANDING/index.php"><img src="../IMG/logoTeste.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>
  <div class="container">
    <main>
      <section class="area-cadastro">
        <div class="form-cadastro">
          <form id="form-section" action="cadastrar.php" method="POST">
            <h1 id="text-form">Crie seu cadastro!</h1>
            <div class="half-input">
              <div class="flex-input input-left">
                <label for="Nome">Nome<span id="asterisk">*</span></label>
                <input class="required" type="text" name="nome" minlength="2" id="nome" oninput="NameValidate()">
                <span class="span-alert">O nome deve ter no mínimo 2 caracteres!</span>
              </div>
              <div class="flex-input input-right">
                <label for="Sobrenome">Sobrenome</label>
                <input class="required" type="text" name="sobrenome" oninput="LastNameValidate()">
                <span class="span-alert">O sobrenome deve ter no mínimo 2 caracteres!</span>
              </div>
            </div>
            <label class="lbl-form" for="Email">Email<span id="asterisk">*</span></label>
            <input class="form-input required" type="email" name="email" placeholder="name@email.com" minlength="1" oninput="EmailValidate()">
            <span class="span-alert span-width">Email inválido!</span>

            <label class="lbl-form" for="Senha">Senha<span id="asterisk">*</span></label>
            <input class="form-input required" type="text" name="senha" placeholder="" minlength="8" oninput="PasswordValidate()">
            <span class="span-alert span-width">Insira todos os caracteres!</span>

            <label class="lbl-form" for="Senha">Confirmar Senha<span id="asterisk">*</span></label>
            <input class="form-input required" type="text" name="conf-senha" placeholder="" minlength="8" oninput="PasswordValidate()">
            <span class="span-alert span-width">As senha não conferem!</span>

            <label class="lbl-form" for="Senha">Data de Nascimento<span id="asterisk">*</span></label>
            <input class="form-input required" type="date" name="data-nascimento">
            <span class="span-alert span-width">Data Inválida!</span>
            <div class="half-input">
              <div class="flex-input input-left">
                <label for="CPF">CPF<span id="asterisk">*</span></label>
                <input id="CPF" class="required" type="text" name="CPF" placeholder="XXX.XXX.XXX-XX" minlength="14" maxlength="14" oninput="CpfValidate()">
                <span class="span-alert">Campo inválido</span>
              </div>
              <div class="flex-input input-right">
                <label for="Tel">Telefone<span id="asterisk">*</span></label>
                <input id="telefone" class="required" type="tel" name="telefone" placeholder="(XX)XXXXX-XXXX" minlength="14" maxlength="14" oninput="PhoneValidate()">
                <span class="span-alert">Campo inválido</span>
              </div>
            </div>

            <div id="fade" class="hide half-input">
              <div id="loader" class="" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
              <div id="message" class="hide">
                <div class="alert alert-light" role="alert">
                  <h4>Mensagem:</h4>
                  <p></p>
                  <button id="close-message" type="button" class="btn btn-secondary">
                    Fechar
                  </button>
                </div>
              </div>
            </div>
            <div id="address-form" class="other-input">
              <form id="address-form" class="">

                <!--input cep-->
                <div class="cep-section">
                  <label for="cep">Digite o seu CEP</label>
                  <div class="form-floating">
                    <input type="text" class=" form-input required " id="cep" name="cep" placeholder="" placeholder="XXXXX-XXX" minlength="9" maxlength="9" onkeyup="handleZipCode(event)" required />
                  </div>
                </div>

                <!--input RUA-->
                <article class="others">
                  <div class="rua">
                    <label for="address">Rua</label>
                    <div class="a form-floating">
                      <input type="text" class=" form-input required shadow-none" id="address" name="endereco" placeholder="" disabled required data-input >
                      <span class="span-alert span-width">Campo inválido</span>
                    <!--input N*RESIDENCIA-->
                    </div>
                    <label for="number">Digite o N° da residência</label>
                    <div class="a form-floating">
                      <input type="text" class=" form-input required shadow-none" id="number" name="numero" placeholder="" disabled required data-input >
                      <span class="span-alert span-width">Campo inválido</span>
                    </div>
                  </div>
                      
                    <!--input COMPLEMENTO TEM QUE ADICIONALO NO BANCO DE DADOS-->
                  <div class="bairro"><label for="complement">Digite o complemento</label>
                    <div class="a form-floating">
                      <input type="text" class=" form-input required shadow-none" id="complement" name="numero" placeholder="" disabled data-input >
                    
                      <!--input BAIRRO-->
                  </div><label for="neighborhood">Bairro</label>
                    <div class="a form-floating">
                      <input type="text" class=" form-input required shadow-none" id="neighborhood" name="bairro" placeholder="" disabled required data-input >
                      <span class="span-alert span-width">Campo inválido</span>
                    </div>
                  </div>

                    <!--input CIDADE-->
                  <div class="bairro"><label for="city">Cidade</label>
                    <div class="cidade form-floating">
                      <input type="text" class=" form-input required shadow-none" id="city" name="cidade" placeholder="" disabled required data-input >
                      <span class="span-alert span-width">Campo inválido</span>
                    </div> 

                    <div class="bairro"><!--classe com nome estranho-->
                      <!--input ESTADO-->
                      <select class="form-select shadow-none  form-input required " id="region" name="estado" disabled required data-input required>
                        <option value="AC">Acre</option>
                        <option value="AL">Alagoas</option>
                        <option value="AP">Amapá</option>
                        <option value="AM">Amazonas</option>
                        <option value="BA">Bahia</option>
                        <option value="CE">Ceará</option>
                        <option value="DF">Distrito Federal</option>
                        <option value="ES">Espírito Santo</option>
                        <option value="GO">Goiás</option>
                        <option value="MA">Maranhão</option>
                        <option value="MT">Mato Grosso</option>
                        <option value="MS">Mato Grosso do Sul</option>
                        <option value="MG">Minas Gerais</option>
                        <option value="PA">Pará</option>
                        <option value="PB">Paraíba</option>
                        <option value="PR">Paraná</option>
                        <option value="PE">Pernambuco</option>
                        <option value="PI">Piauí</option>
                        <option value="RJ">Rio de Janeiro</option>
                        <option value="RN">Rio Grande do Norte</option>
                        <option value="RS">Rio Grande do Sul</option>
                        <option value="RO">Rondônia</option>
                        <option value="RR">Roraima</option>
                        <option value="SC">Santa Catarina</option>
                        <option value="SP">São Paulo</option>
                        <option value="SE">Sergipe</option>
                        <option value="TO">Tocantins</option>
                      </select>
                    </div>
                  </div>
                  <div class="d-flex justify-content-end">

                  </div>

            </div>
            </article>

            <div class="input-radio">
              <div class="radio-section">
                <input class="required" type="radio" name="genero" value="Masculino">
                <label class="lbl-form" for="genero">Masculino</label>
              </div>
              <div class="radio-section">
                <input class="required" type="radio" name="genero" value="Feminino">
                <label class="lbl-form" for="genero">Feminino</label>
              </div>
              <div class="radio-section">
                <input class="required" type="radio" name="genero" value="Outro">
                <label class="lbl-form" for="genero">Outros</label>
              </div>
            </div>
            <input class="form-input required" id="btn-logar" type="submit" name="Logar" value="Logar">
          </form>
        </div>
      </section>
    </main>
  </div>
</body>
<script src="scripts.js" defer></script>
<script src="mascara.js"></script>
</html>
<?php
// Include com conexao.php, como se fosse herança em POO
session_start();
include('conexao.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$telefone = $_POST['telefone'];
$genero = $_POST['genero'];
$dt_nasc = $_POST['data-nascimento'];
$cep = $_POST['cep'];
$endereco = $_POST['endereco'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$uf = $_POST['estado'];
$numero = $_POST['numero'];



/*$CPF = $_POST['CPF'];*/     /* COLOCAR NO BANCO DE DADOS */ 
/*$sobrenome = $_POST['sobrenome'];*/    /* COLOCAR NO BANCO DE DADOS  */ 

if(empty($_POST['nome']) || empty($_POST['email']) || empty($_POST['senha']) || empty($_POST['telefone']) || empty($_POST['genero']) || empty($_POST['data-nascimento']) || empty($_POST['cep'])
|| empty($_POST['endereco']) || empty($_POST['bairro']) || empty($_POST['cidade']) || empty($_POST['estado']) || empty($_POST['numero'])){
    header('Location: cadastro.php');
    exit();
}
else {
    $insert = mysqli_query($conexao, "INSERT INTO cadastro(nome,email,senha,telefone,genero,data_nascimento,cep,endereco,bairro,cidade,uf,numero,data_cadastro) VALUES('$nome','$email',md5('$senha'),'$telefone','$genero','$dt_nasc','$cep','$endereco','$bairro','$cidade','$uf','$numero',sysdate());");

    if (!$insert) 
    {
        echo "Erro ao inserir no banco de dados: " . mysqli_error($conexao);
    }
    header('Location: ../CADASTRO_PET/cadastropet.php');
}


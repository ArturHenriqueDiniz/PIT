<!DOCTYPE html>
<html lang="en">
<head>
<?php
        header('Content-type: text/html; charset=utf-8');
    ?>
    <meta charset="UTF-8">
    <link rel="icon" href="../IMG/Logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LANDING/index.php"><img src="../IMG/Logo.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>
    <main>
        <section class="area-login">
            <div class="form-login">
                <form id="form-section"action="./login.php" method="POST">
                    <input type="text" name="email" placeholder="Email">
                    <input type="password" name="senha" placeholder="Senha">
                    <label id="lbl-senha"for="Senha"><a href="/Pasta_pit_02/PHP_PIT/ESQUECEUSENHA/index.php">Esqueceu sua senha</a></label>

                    <input id="btn-logar" type="submit" name="Logar" value="Logar">
                    
                    <label id="lbl-cadastro" for=""><a href="../CADASTRO/index.php">Não tem conta?<br>Cadastre-se agora!</a></label>
                </form>
            </div>
            <div class="logar-google">
                <div class="element">
                    <div id="rectangle"></div>
                    <h1>ou</h1>
                    <div id="rectangle"></div>
                </div>
                <a href="../LOGIN_GOOGLE/index.php">
                    <div class="btn-google">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1.5em" viewBox="0 0 488 512"><style>svg{fill:#ffffff}</style><path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/></svg>
                        <h1>Logar com Google</h1>
                    </div>
                </a>
            </div>
        </section>
        <figure class="area-img-login">
            <figcaption><h1>É bom ver você por aqui!</h1></figcaption>
            <img src="https://img.freepik.com/vetores-gratis/ilustracao-de-desenho-animado-de-cachorro-fofo-e-gato-fofo_138676-3238.jpg?w=2000" alt="" width="350px" height="350px">
        </figure>
    </main>
</body>
<script src="mascara.js"></script>
</html>
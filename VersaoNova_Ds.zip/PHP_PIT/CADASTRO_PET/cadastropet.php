<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Petch - Cadastro</title>
  <link rel="stylesheet" href="cadastropet.css">
  <link rel="icon" href="../IMG/Logo.png">
</head>

<?php
        header('Content-type: text/html; charset=utf-8');
    ?>

<body>
  <div id="cabecalho">
    <ul class="ul_cabecalho">
      <li><img src="../IMG/Logo.png" height="50px"></li> <!-- AINDA ESTAMOS REALIZANDO O PROCESSO DE CRIAÇÃO DA LOGO ESSE AQUI E SÓ UM EXEMPLO-->
    </ul>
  </div>

  <div id="fundo_cadastro">
    <div id="tamanho_cadastro">
      <form action="cadastrarpet.php" method="POST" enctype="multipart/form-data"> 
        <ul class="ul_cadastro_pet">
          <li>
            <h2 class="centro">Cadastre seu pet já!</h2>
          </li>

          <li>Nome do pet:<input type="text" placeholder="Digite o nome do pet" name="nome"></li>
          <li>Raça:<input type="text" placeholder="Digite a raça do pet" name="raca"></li>
          <li>Data de nascimento:<input type="date" name="dt_nasc"></li>
          <li>Sexo:</li><br>
          <li>
            Macho:<input type="radio" value="Macho" name="genero">
            Femea:<input type="radio" value="Fêmea" name="genero">
          </li>
          <br>
          <li>
            <label class="picture" for="picture__input" tabIndex="0">
              <span class="picture__image"></span>
            </label>
          </li>
          <li><input type="file" name="foto_pet" id="picture__input" accept="image/*" ></li>
          <br> 
          <li><button type="submit" id="cadastro_button" >Finalizar </button></li>
        </ul>
      </form >
    </div>
  </div>
  <script type="text/javascript" src="Pet.js"></script>
</body>


</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        header('Content-type: text/html; charset=utf-8');
        include_once('APICEP.php');
        $address =  pegar_endereço();
    ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous"><link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>Cadastro</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LANDING/index.php"><img src="../IMG/logoTeste.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>
    <div class="container">
        <main>
            <section class="area-cadastro">
                <div class="form-cadastro">
                    <form id="form-section" action="cadastrar.php" method="POST">
                        <h1 id="text-form">Crie seu cadastro!</h1>
                        <div class="half-input">
                            <div class="flex-input input-left">
                                <label for="Nome">Nome<span id="asterisk">*</span></label>
                                <input class="required" type="text" name="nome" minlength="2" id="nome" oninput="NameValidate()">
                                <span class="span-alert">O nome deve ter no mínimo 2 caracteres!</span>
                            </div>
                            <div class="flex-input input-right">
                                <label for="Sobrenome">Sobrenome</label>
                                <input class="required" type="text" name="sobrenome" oninput="LastNameValidate()">
                                <span class="span-alert">O sobrenome deve ter no mínimo 2 caracteres!</span>
                            </div>
                        </div>
                        <label class="lbl-form" for="Email">Email<span id="asterisk">*</span></label>
                        <input class="form-input required" type="email" name="email" placeholder="name@email.com" minlength="1" oninput="EmailValidate()">
                        <span class="span-alert span-width">Email inválido!</span>

                        <label class="lbl-form" for="Senha">Senha<span id="asterisk">*</span></label>
                        <input class="form-input required" type="text" name="senha" placeholder="" minlength="8" oninput="PasswordValidate()">
                        <span class="span-alert span-width">Insira todos os caracteres!</span>
                        
                        <label class="lbl-form" for="Senha">Confirmar Senha<span id="asterisk">*</span></label>
                        <input class="form-input required" type="text" name="conf-senha" placeholder="" minlength="8" oninput="PasswordValidate()">
                        <span class="span-alert span-width">As senha não conferem!</span>
                        
                        <label class="lbl-form" for="Senha">Data de Nascimento<span id="asterisk">*</span></label>
                        <input class="form-input required" type="date" name="data-nascimento">
                        <span class="span-alert span-width">Data Inválida!</span>
                        <div class="half-input">
                            <div class="flex-input input-left">
                                <label for="CPF">CPF<span id="asterisk">*</span></label>
                                <input id="CPF" class="required" type="text" name="CPF" placeholder="XXX.XXX.XXX-XX" minlength="14" maxlength="14" oninput="CpfValidate()">
                                <span class="span-alert">Campo inválido</span>
                            </div>
                            <div class="flex-input input-right">
                                <label for="Tel">Telefone<span id="asterisk">*</span></label>
                                <input id="telefone" class="required" type="tel" name="telefone" placeholder="(XX)XXXXX-XXXX" minlength="14" maxlength="14" oninput="PhoneValidate()">
                                <span class="span-alert">Campo inválido</span>
                            </div>
                        </div>

                        <!--input cep-->
                        <label class="lbl-form" for="CEP">CEP<span id="asterisk">*</span></label>
                        <input id="CEP" class="form-input required" type="text" name="cep" placeholder="XXXXX-XXX" minlength="9" maxlength="9" oninput="handleZipCode(event)" value="<?php echo $address->cep?>">
                        <span class="span-alert span-width">Campo inválido</span>

                        <!--input rua-->
                        <label class="lbl-form" for="Endereco">Endereço<span id="asterisk">*</span></label>
                        <input class="form-input required" type="text" name="endereco" value="<?php echo $address->logradouro?>">
                        <span class="span-alert span-width">Campo inválido</span>
                        
                        <!--input bairro-->
                        <div class="half-input">
                            <div class="flex-input input-left">
                                <label for="Bairro">Bairro<span id="asterisk">*</span></label>
                                <input class="required" type="text" name="bairro" value="<?php echo $address->bairro?>">
                                <span class="span-alert">Campo inválido</span>
                            </div>

                        <!--input cidade-->
                            <div class="flex-input input-right">
                                <label for="Cidade">Cidade<span id="asterisk">*</span></label>
                                <input class="required" type="text" name="cidade" value="<?php echo $address->localidade?>">
                                <span class="span-alert">Campo inválido</span>
                            </div>
                        </div>

                        <!--input UF-->
                        <div class="half-input">
                            <div class="flex-input input-left">
                                <label for="UF">UF<span id="asterisk">*</span></label>
                                <input class="required" type="text" name="estado" value="<?php echo $address->uf?>">
                                <span class="span-alert">Campo inválido</span>
                            </div>

                            <!--/NOMERO-->
                            <div class="flex-input input-right">
                                <label for="Numero">Número<span id="asterisk">*</span></label>
                                <input class="required" type="text" name="numero">
                                <span class="span-alert">Campo inválido</span>
                            </div>
                        </div>

                        <!--/GENERO-->
                        <label class="lbl-form" for="Endereco">Gênero <span id="asterisk">*</span></label>
                        <div class="input-radio">
                            <div class="radio-section">
                            <input class="required" type="radio" name="genero" value="Masculino">
                                <label class="lbl-form" for="genero">Masculino</label>
                            </div>

                            <div class="radio-section">
                            <input class="required" type="radio" name="genero" value="Feminino">
                                <label class="lbl-form" for="genero">Feminino</label>
                            </div>

                            <div class="radio-section">
                            <input class="required" type="radio" name="genero" value="Outro">
                                <label class="lbl-form" for="genero">Outro</label>
                            </div>
                        </div>
                        <input class="form-input required" id="btn-logar" type="submit" name="Logar" value="Logar">
                    </form>
            </section>
        </main>
    </div>
</body>
<script src="mascara.js"></script>
<script src="CEPJava.js"></script>
</html>
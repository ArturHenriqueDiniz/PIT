<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="a.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>ATUALIZAR SENHA</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LANDING/index.html"><img src="../IMG/logoTeste.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>


    <main>
        <section class="area-login">
            <div class="form-login">


            <?php
session_start();






$pass = "";
$dbname = "BancoDeDados_Petch";
$host = "localhost"; // ou substitua pelo endereço IP do servidor MySQL
$port = 3306;
$user = "root"; // Defina o valor correto do usuário

try {
    $conn = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $err) {
    echo $err->getMessage();
}

$chave = filter_input(INPUT_GET, 'chave', FILTER_DEFAULT);
//var_dump($chave);

$query_cadastro = "SELECT id_usuario
FROM cadastro
WHERE recuperar_senha = :recuperar_senha
LIMIT 1";
$result_usuario = $conn->prepare($query_cadastro);
$result_usuario->bindParam(':recuperar_senha', $chave, PDO::PARAM_STR);
$result_usuario->execute();

if (($result_usuario) && ($result_usuario->rowCount() != 0)) {
    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
   // var_dump($dados);
    if (!empty($dados['SendNovSenha'])) {
        $senha_usuario = password_hash($dados['senha_usuario'], PASSWORD_DEFAULT);
        $recuperar_senha = 'NULL';
        $query_up_usuario = "UPDATE cadastro
         SET senha = :senha,
         recuperar_senha =:recuperar_senha
         WHERE id_usuario = :id
         LIMIT 1";
        $result_up_usuario = $conn->prepare($query_up_usuario);
        $result_up_usuario->bindParam(':senha', $senha_usuario, PDO::PARAM_STR);
        $result_up_usuario->bindParam(':recuperar_senha', $recuperar_senha);

        $result_usuario_row = $result_usuario->fetch(PDO::FETCH_ASSOC);
        $result_up_usuario->bindParam(':id', $result_usuario_row['id_usuario'], PDO::PARAM_INT);

        if ($result_up_usuario->execute()) {
            $_SESSION['senha_atualizada'] = "Senha atualizada com sucesso!";
            header("Location: ../LOGIN/index.html");
            exit();
        } else {
            $_SESSION['msg_rec'] = "Erro ao atualizar a senha. Por favor, tente novamente!";
            header("Location: atualizar_senha.php");
            exit();
        }
    }
} else {
    $_SESSION['msg_rec'] = "Erro: Link inválido! Solicite um novo link para atualizar a senha!";
    header("Location: atualizar_senha.php");
    exit();
}

?>








<form method="POST"  id="form-section" action="">
    <?php
    $senha_usuario = "";
    if (isset($dados['senha_usuario'])) {
        $senha_usuario = $dados['senha_usuario'];
    }
    ?>
    <label>Atualizar Senha</label>
    <input type="password" name="senha_usuario" placeholder="Digite a nova senha" value="<?php echo $senha_usuario; ?>" /><br>
    <input id="btn-logar" type="submit" value="Atualizar" name="SendNovSenha">

</form>
<br> 
<br><div id ="aliunk">Lembrou? <a  href="../LOGIN/index.html" style='color: #8B4513'>Clique aqui</a> para logar
</div></div>
</section>
</main>
    
</body>
</html>
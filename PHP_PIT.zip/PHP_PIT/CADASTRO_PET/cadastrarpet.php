<?php
// Include com conexao.php, como se fosse herança em POO
session_start();
include('conexao.php');

$nome = $_POST['nome'];
$raca = $_POST['raca'];
$dt_nasc = $_POST['dt_nasc'];
$genero = $_POST['genero'];

if (isset($_FILES['foto_pet'])) {
    $ext = strtolower(substr($_FILES['foto_pet']['name'], -4)); //Pegando extensão do arquivo
    $new_name = date("Y.m.d-H.i.s") . $ext; //Definindo um novo nome para o arquivo
    $dir = './imagens/'; //Diretório para uploads
    move_uploaded_file($_FILES['foto_pet']['tmp_name'], $dir . $new_name); //Fazer upload do arquivo
}  

if(empty($_POST['nome']) || empty($_POST['raca']) || empty($_POST['dt_nasc']) || empty($_POST['genero']) || empty($_FILES['foto_pet'])){
     header('Location: cadastropet.php');
     exit();
}

else {
    $insert = mysqli_query($conexao, "INSERT INTO cadastropet(nome, raca, data_nascimento, genero,fk, imagem_pet) VALUES('$nome','$raca','$dt_nasc','$genero','1','$new_name');");
    header('Location: ../LOGIN/index.php');
     exit();
}  


<!--Inicio do form-->
      <form class="row d-flex align-items-bottom justify-content-center" action="valida.php" method="POST">
<!--Inicio da imagem-->
  <div class="col-md-10">
    <img src="assets/folha2.png" alt="logo" width="300" height="300" style="vertical-align:middle" class="img-fluid" > </div> <!--Fim da imagem-->
  <div class="col-auto">
    <label for="#">Login-Email</label>
      <input type="email" class="form-control" name="login" placeholder="digite seu email"><br>
    <label for="#">Senha</label>
      <input type="password" class="form-control" name="senha" placeholder="digite sua senha"><br> 
    <button type="submit" class="btn btn-primary mb-3">Logar</button>
  </div>
  </div><!--Fim do card-body--> 
</form> <!--Final do form-->
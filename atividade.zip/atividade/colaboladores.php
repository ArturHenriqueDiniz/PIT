<!DOCTYPE HTML>
<html lang="pt-br">   
    <head>   
    <meta charset="UTF-8">    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" 
    crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" 
    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" 
    crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD"  crossorigin="anonymous">
    <title>CLIENTES</title>
  
    </head>
<body>
  
<form>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">ID_COLABORADOR</label>
    <input type="text" class="form-control" id="nome">
    <div id="nome" class="form-text">Digite o ID do Colaborador.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nome</label>
    <input type="text" class="form-control" id="nome">
    <div id="nome" class="form-text">Digite o nome do Colaborador.</div>
  </div>

 <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">CPF</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite o CPF do Colaborador.</div>
 </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Email</label>
    <input type="email" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite o E-MAIL do Colaborador.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Telefone</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite o Telefone do Colaborador.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Endereco</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite o ENDERECO do Colaborador.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Cargo</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite o Cargo do Colaborador.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Salario</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
    <div id="nome" class="form-text">Digite a Salario do Colaborador.</div>
  </div>

<button type="submit" class="btn btn-primary">Gravar</button>
</form>

</body>
</html>
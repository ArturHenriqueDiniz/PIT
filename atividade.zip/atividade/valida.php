<?php

if (isset($_POST['login']) && ($_POST['senha']) ) 
{
  $login = $_POST['login'];
  $senha = $_POST['senha'];

  if ($login == "aluno@gmail.com" && $senha=="123") {
    session_start();
    $_SESSION['login_session'] = $login;
    session_id();
    header("Location:principal1.php");
  }
  else 
  header ("Location:login.php");
}

else
{
  echo"Valores nulos";
}
?>
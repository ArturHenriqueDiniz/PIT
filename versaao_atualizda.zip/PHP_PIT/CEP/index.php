<!DOCTYPE html>
<html>

<head>
    <script src="CEPJava.js"></script>
    <?php
    header('Content-type: text/html, charset=utf-8');
    include_once('APICEP.php');
    $address =  pegar_endereço();
?>
    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Consumindo API</title>
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    </head>

<body>
    <form onload="APICEP.php" action="." method="post">
        <p>Digite o CEP para encontrar o endereço.</p>
        <input type="text" name="cep" onkeyup="handleZipCode(event)" maxlength="9"

            value="<?php echo $address->cep?>">
        <input type="submit" style="position: absolute; width: 1px; height: 1px;DISPLAY:NONE" tabindex="-1" />
        <input type="text" placeholder="rua" name="rua" value="<?php echo $address->logradouro?>">
        <input type="text" placeholder="bairro" name="bairro" value="<?php echo $address->bairro?>">
        <input type="text" placeholder="cidade" name="cidade" value="<?php echo $address->localidade?>">
        <input type="text" placeholder="estado" name="estado" value="<?php echo $address->uf?>">
    </form>
</body>
<?php

function PegarCEP(string $cep){
    $url = "https://viacep.com.br/ws/{$cep}/json/";//integracao
    return json_decode(file_get_contents($url));
}
    
function pegar_endereço(){

if(isset($_POST['cep']))
{  $cep= $_POST['cep'];

    $cep = filterCep ($cep);
    if ( isCep ($cep))
    {
    $address = PegarCEP($cep);
    if(property_exists($address,'erro'))
    {
        $address = EndereçoVazio(); //zerar os campos
        echo '<form method="post" action="">
        
        <div id="meu-alerta" class="alert alert-warning alert-dismissible" role="alert">
    
            <span aria-hidden="true">&times;</span>
        
        <t>CEP não encontrado!</t> </button>
        </div>
    </form>
    <script>
    setTimeout(function(){
        document.getElementById("meu-alerta").style.display = "none";
    }, 2000); 
</script>';
// Esse é a mensagem de Alert 
    }
    }
    else
    {
        $address = EndereçoVazio();
        echo  '<form method="post" action="">
        
        <div id="meu-alerta" class="alert alert-warning alert-dismissible" role="alert">
    
            <span aria-hidden="true">&times;</span>
        
        <t>CEP não encontrado!</t> </button>
        </div>
    </form>
    <script>
    setTimeout(function(){
        document.getElementById("meu-alerta").style.display = "none";
    }, 2000); 
</script>';
   
    }
}else{
    $address = EndereçoVazio();
}
   
return $address;

}

function IsCep(string $cep):bool{
return preg_match('/^[0-9]{5}-?[0-9]{3}$/',$cep); 
}
// funcao para verificar se é um cep
function filterCep(string $cep):string{
   $cep = preg_replace('/[^0-9]/', '', $cep); 
    $cep = str_pad($cep, 8, '0', STR_PAD_LEFT); 
    
    $parte1 = substr($cep, 0, 5); 
    $parte2 = substr($cep, 5, 3); 
    
    $cepFormatado = $parte1 . '-' . $parte2; 
    
    return $cepFormatado;
    // funcao de formatacao

}

function EndereçoVazio(){
        return(object) [
    
        'cep' => ' ',
        'logradouro' => ' ',
        'bairro' => ' ',
        'localidade' => ' ',
        'uf' => ' '
    
    ];
}

if (isset($_POST['fechar_alerta'])) {
    echo '<style>#meu-alerta { display: none; }</style>';
}

?>
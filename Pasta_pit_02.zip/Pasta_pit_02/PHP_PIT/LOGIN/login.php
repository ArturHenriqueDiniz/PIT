<?php
// Include com conexao.php, como se fosse herança em POO
session_start();
include('conexao.php');

if(empty($_POST['email']) || empty($_POST['senha'])){
    header('Location: ./index.php');
    exit();
}

$email = mysqli_real_escape_string($conexao, $_POST['email']);
$senha = mysqli_real_escape_string($conexao,  md5($_POST['senha']));


$query = "select email, senha from cadastro where email = '{$email}' and senha = '{$senha}';";
$result = mysqli_query($conexao, $query);
$row = mysqli_num_rows($result);

if($row == 1){
    $_SESSION['email'] = $email;
    echo "{$email}<br>{$senha}<br>";
    echo "Achou o usuario";
    header('Location: ../PG_INICIAL/index.php');
    exit();
    
}
else{
    echo "{$email}<br>{$senha}<br>";
    echo "Não achou o usuario";
    header('Location: ./index.php');
    exit();
    
}
?>
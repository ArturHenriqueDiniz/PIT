create database BancoDeDados_Petch1;
use BancoDeDados_Petch1;
create table cadastro(
id_usuario int unsigned primary key not null auto_increment,
nome varchar(60) not null,
email varchar(60) not null,
senha varchar(32) not null,
telefone char(14) not null,
genero varchar(10) not null,
data_nascimento date not null,
cep char(9) not null,
endereco varchar(40) not null,
bairro varchar(40) not null,
cidade varchar(40) not null,
uf char(2) not null,
numero int,
data_cadastro datetime not null
);

create table cadastropet(
id_usuario int unsigned primary key not null auto_increment,
nome varchar(60) not null,
raca varchar(20) not null,
data_nascimento date not null,
genero char(5) not null,
fk int unsigned not null,
foreign key (fk) references cadastro(id_usuario)
on delete cascade,
imagem_pet longblob not null
);

describe cadastro;

select * from cadastro;
select * from cadastropet;
delete from cadastro where id_usuario > 1;

truncate cadastro;
truncate cadastropet;

-- https://pt.stackoverflow.com/questions/264678/combo-box-e-input-text

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="a.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>RECUPERAR SENHA</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LOGIN/index.php"><img src="../IMG/logoTeste.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>


    <main>
        <section class="area-login">
            <div class="form-login">

            <?php
session_start(); // Inicie a sessão
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'lib/vendor/autoload.php';

$mail = new PHPMailer(true);
$pass = "";
$dbname = "BancoDeDados_Petch1";
$host = "localhost"; // ou substitua pelo endereço IP do servidor MySQL
$port = 3306;
$user = "root"; // Defina o valor correto do usuário

try {
    $conn = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $err) {
    echo $err->getMessage();
}

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if (!empty($dados['SendRecupSenha'])) {
    //var_dump($dados);
    $query_cadastro = "SELECT id_usuario, nome, email
    FROM cadastro
    WHERE email = :email
    LIMIT 1";
    $result_usuario = $conn->prepare($query_cadastro);
    $result_usuario->bindParam(':email', $dados['email'], PDO::PARAM_STR);

    $result_usuario->execute();

    if ($result_usuario->rowCount() != 0) {
        $row_usuario = $result_usuario->fetch(PDO::FETCH_ASSOC); 
        $chave_recuperar_senha = password_hash($row_usuario['id_usuario'], PASSWORD_DEFAULT);

        $query_up_usuario = "UPDATE cadastro
        SET recuperar_senha = :recuperar_senha
        WHERE id_usuario = :id_usuario
        LIMIT 1";
        $result_up_usuario = $conn->prepare($query_up_usuario);
        $result_up_usuario->bindParam(':recuperar_senha', $chave_recuperar_senha, PDO::PARAM_STR); 
        $result_up_usuario->bindParam(':id_usuario', $row_usuario['id_usuario'], PDO::PARAM_STR);

        if ($result_up_usuario->execute()) {
            $link = "http://localhost/PIT/ESQUECEUSENHA/atualizar_senha.php?chave=$chave_recuperar_senha";

            try {
                //$mail->SMTPDebug = false; // Desativa a exibição de informações de depuração
                $mail->CharSet = 'UTF-8';
                $mail->isSMTP();
                $mail->Host       = 'sandbox.smtp.mailtrap.io';
                $mail->SMTPAuth   = true;
                $mail->Username   = '86cf4f6158313a';
                $mail->Password   = 'd531bd8c5974df';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 2525;

                $mail->setFrom('atendimento_pet@petch.com.br', 'Atendimento');
                $mail->addAddress($row_usuario['email'], $row_usuario['nome']);

                $mail->isHTML(true);
                $mail->Subject = 'Recuperar Senha';
                $mail->Body    = 'Prezado(a) ' . $row_usuario['nome'] . ",<br><br>
                Você solicitou alteração de senha. <br><br>
                Para continuar o processo de recuperação de sua senha, clique no link abaixo ou cole o endereço no seu navegador: <br><br>
                <a href='" . $link . "'>" . $link . "</a><br><br>
                Se você não solicitou essa alteração, nenhuma ação é necessária. Sua senha permanecerá a mesma até que você ative este código.<br><br>";
                $mail->AltBody = 'Prezado(a) ' . $row_usuario['nome'] . ",\n\n
                Você solicitou alteração de senha.\n\n
                Para continuar o processo de recuperação de sua senha, clique no link abaixo ou cole o endereço no seu navegador:\n\n
                " . $link . "\n\n
                Se você não solicitou essa alteração, nenhuma ação é necessária. Sua senha permanecerá a mesma até que você ative este código.\n\n";

                $mail->send();
                $_SESSION['msg'] = "<p style='color: green'>Enviado e-mail com instruções para recuperar a senha. Acesse a sua caixa de e-mail para recuperar a senha!</p>";
                header("Location: ../LOGIN/index.html");
                exit();
            } catch (Exception $e) {
                echo "Erro: Email não enviado com sucesso. Mailer Error: {$mail->ErrorInfo}";
            }

        } else {
           echo  "<p style='color: #ff1000'>Erro: Tente novamente!</p>";
        }
    } else {
       echo "<p style='color: #ff0000'>Erro: Usuário não encontrado!</p>";
    }
}

if (isset($_SESSION['msg_rec'])) {
    echo $_SESSION['msg_rec'];
    unset ($_SESSION['msg_rec']);
}

?>


<form method="POST" id="form-section" action="">
    <label>RECUPERAR A SENHA</label>

    <input type="text" name="email" placeholder="email">
    <input id="btn-logar" type="submit" name="SendRecupSenha" value="Recuperar">

    <label id="lbl-cadastro" for="">
        <a href="../LOGIN/index.html">Voltar</a>
    </label>
</form>
            </div>
       
        </section>

    </main>
    
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>LOGIN GOOGLE</title>
</head>
<?php
session_start();
?>

<body>
    <header>
        <div class="header">
            <div class="div-header-left">
                <div class="logo">
                    <span>
                        <a href="../LANDING/index.php"><img src="../IMG/logoTeste.png" alt="Logo" width="50px"></a>
                    </span>
                </div>
            </div>
        </div>
    </header>
    <main>
        <section class="area-login">
            <div class="form-login">
                <form id="form-section"action="">
                    <input type="text" name="Email" placeholder="Email">
                    <input type="password" name="Senha" placeholder="Senha">
                    <label id="lbl-senha"for="Senha"><a href="/Pasta_pit_02/PHP_PIT/ESQUECEUSENHA/index.php">Esqueceu sua senha</a></label>
                    <input id="btn-logar" type="submit" name="Logar" value="Logar">
                    <label id="lbl-cadastro" for=""><a href="../CADASTRO/index.php">Não tem conta?<br>Cadastre-se agora!</a></label>
                </form>
            </div>
            
            <div class="logar-google">
                <div class="element">
                    <div id="rectangle"></div>
                    <h1>ou</h1>
                    <div id="rectangle"></div>
                </div>
             
                    <script src="https://accounts.google.com/gsi/client" async defer></script>
                        <div id="g_id_onload"
                            data-client_id="458060386286-i6bgmne1ighbp0q41kc10mddo7jpt2k6.apps.googleusercontent.com"
                            data-login_uri="/Pasta_pit_02/PHP_PIT/PG_INICIAL/index.php"
                            data-auto_prompt="false">
                        </div>
                        <div class="g_id_signin"
                            data-type="standard"    
                            data-size="large"
                            data-theme="outline"
                            data-text="sign_in_with"
                            data-shape="rectangular"
                            data-logo_alignment="left">
                        </div>
                
            </div>
        </section>
        <figure class="area-img-login">
            <figcaption><h1>Tão bom ver você por aqui!</h1></figcaption>
            <img src="https://img.freepik.com/vetores-gratis/ilustracao-de-desenho-animado-de-cachorro-fofo-e-gato-fofo_138676-3238.jpg?w=2000" alt="" width="350px" height="350px">
        </figure>
    </main>
</body>
</html>